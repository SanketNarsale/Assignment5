import { Component } from '@angular/core';

@Component({
  selector: 'app-secondcomp',
  standalone: true,
  imports: [],
  templateUrl: './secondcomp.component.html',
  styleUrl: './secondcomp.component.css'
})
export class SecondcompComponent {

}
