import { Component } from '@angular/core';

@Component({
  selector: 'app-fisr-comp',
  standalone: true,
  imports: [],
  templateUrl: './fisr-comp.component.html',
  styleUrl: './fisr-comp.component.css'
})
export class FisrCompComponent {

}
