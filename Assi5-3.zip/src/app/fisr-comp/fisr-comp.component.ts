import { Component } from '@angular/core';
import { SecondcompComponent } from '../secondcomp/secondcomp.component';

@Component({
  selector: 'app-fisr-comp',
  standalone: true,
  imports: [SecondcompComponent],
  templateUrl: './fisr-comp.component.html',
  styleUrl: './fisr-comp.component.css'
})
export class FisrCompComponent {

}
